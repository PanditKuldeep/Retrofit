package com.example.kuldeep.retrofit.Retrofit.helper;


import com.example.kuldeep.retrofit.Retrofit.model.get_cat;
import com.example.kuldeep.retrofit.Retrofit.model.model;
import com.example.kuldeep.retrofit.URLS;
import java.util.ArrayList;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;


public interface APIInterface {
    @GET(URLS.CATEGORY)
    Call<ArrayList<model>> model();

    @POST(URLS.GET_CAT)
    Call<get_cat> get_cat();

    @FormUrlEncoded
    @POST(URLS.GET_CAT)
    Call<get_cat> send_cat(
            @Field("parameter") String dummy_,
            @Field("parameter") String dummy);
}