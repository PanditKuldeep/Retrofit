package com.example.kuldeep.retrofit.Retrofit.model;

import com.google.gson.annotations.SerializedName;

public class model {
    @SerializedName("key")
    public String key;
    @SerializedName("key")
    public String key_one;
    @SerializedName("key")
    public String kp;
}