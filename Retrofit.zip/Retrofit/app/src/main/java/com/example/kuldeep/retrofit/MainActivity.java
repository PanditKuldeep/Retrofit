package com.example.kuldeep.retrofit;

import android.app.ProgressDialog;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import com.example.kuldeep.retrofit.Retrofit.helper.APIInterface;
import com.example.kuldeep.retrofit.Retrofit.helper.ApiClient;
import com.example.kuldeep.retrofit.Retrofit.model.get_cat;
import com.google.gson.Gson;
import java.util.ArrayList;


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private Context context;
    RecyclerView recyclerView;
    private ProgressDialog pDialog;
    ArrayList<get_cat.Result_data> result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        context = MainActivity.this;
        onPreExecute();
        call_api();
    }
    protected void onPreExecute() {
        // Showing progress dialog
        pDialog = new ProgressDialog(MainActivity.this);
        pDialog.setMessage("Please wait...");
        pDialog.setCancelable(false);
        pDialog.show();
    }

    private void call_api() {
        try {

            APIInterface apiInterface = ApiClient.getClient(context).create(APIInterface.class);
            Call<get_cat> Call = apiInterface.get_cat();

            Call.enqueue(new Callback<get_cat>() {
                @Override
                public void onResponse(@NonNull Call<get_cat> call, @NonNull Response<get_cat> response) {
                    try {
                        pDialog.dismiss();
                        Log.d("is_success",""+new Gson().toJson(response.body()));
                        get_cat model = response.body();
                        if (model != null) {

                            if (model.is_success.equalsIgnoreCase("true")) {
                                Log.d("is_success",""+model.is_success);
                                result = model.result_data;
                                VetAdapter adapter = new VetAdapter(context,result);
                                recyclerView.setAdapter(adapter);
                            } else {
                                // response false
                            }
                        }else {
                          // error message
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        Log.d("sub_catch",""+ e);
                    }
                }

                @Override
                public void onFailure(@NonNull Call<get_cat> call, @NonNull Throwable t) {
                    pDialog.dismiss();
                    Log.d("Fail",""+ t);
                }
            });


        } catch (Exception e) {
            e.printStackTrace();
            Log.d("main_catch",""+ e);
        }

    }

}
