package com.example.kuldeep.retrofit.Retrofit.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;


public class get_cat {


    @SerializedName("key_name")
    @Expose
    public String is_success;

    @SerializedName("key_name")
    @Expose
    public ArrayList<Result_data> result_data = null;

    public class Result_data{

        @SerializedName("key_name")
        @Expose
        public String id;

        @SerializedName("key_name")
        @Expose
        public String topic_name;

        @SerializedName("key_name")
        @Expose
        public String status;

    }
}
