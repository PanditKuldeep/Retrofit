package com.example.kuldeep.retrofit;



public class URLS {

    public static String DOMAIN = "common base url";

    public static final String CATEGORY = "/";
    public static final String GET_CAT = "/";

}
